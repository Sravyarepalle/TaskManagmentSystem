package com.task.TaskManagement.Constants;

public class CommonConstants {
    private CommonConstants() {
    }

//    public static final String SUCCESS = "SUCCESS";
//
//    public static final String FAILED = "FAILED";
//
   public static final String YES = "Y";

    public static final String IS_ADMIN = "IS_ADMIN";
}
